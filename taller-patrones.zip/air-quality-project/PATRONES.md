# PATTERNS.md - Air Quality Network

Only three patterns are used: Factory Method, Prototype and Builder.

## 1. Factory Method
**Where:** package `puesto` (creator) and package `analizador` (products).
- `PuestoDeMonitoreo` is the abstract creator. Its public method `procesarJornada(List<LecturaCruda>)` runs the process (discard, correct, check validity, average, ICA) and calls the factory method `protected abstract Analizador crearAnalizador(String contaminante)`.
- `PuestoFijoReferencia`, `PuestoMovil` and `PuestoBajoCosto` override it and return `AnalizadorMetodoReferencia`, `AnalizadorOpticoPortatil` or `SensorBajoCosto`.

**Why:** each type of station needs a different analyzer, but the process is always the same. The station does not use `if` to choose a correction: the correction lives in each analyzer (`corregir`). To add a new station type we only add a new station class and a new analyzer.

## 2. Prototype
**Where:** package `configuracion`, class `ConfiguracionEstacion`.
- It implements `Cloneable` and overrides `clone()` to make a deep copy: a new `ArrayList` for the pollutants, a new `LinkedHashMap` for the thresholds, and a new `TareaMantenimiento` object for each task of the maintenance plan.

**Why:** a new station is 90 % equal to a model configuration, so we clone the model and adjust the copy instead of writing everything from zero. The deep copy prevents two stations from sharing the same map or list. The demo shows that changing a threshold and adding a task in one clone does not change the model or the other clone.

## 3. Builder
**Where:** package `boletin`, class `BoletinDiario` with its inner class `BoletinDiario.Builder`.
- `BoletinDiario` has a private constructor, only final fields and no setters, so it is immutable.
- The Builder has fluent methods (mandatory: date, issuing entity, station results, city maximum ICA, city category; optional: recommendations, forecast, missing data annex, responsible, methodological note).
- `build()` throws `IllegalStateException` if a mandatory field is missing, if the station list is empty, or if the category is "Unhealthy" or worse (the English name of "Dañina a la salud") and there are no recommendations.

**Why:** the bulletin has many fields and some are optional, so a constructor with many parameters would be confusing. The Builder validates everything in one place before the object exists.
