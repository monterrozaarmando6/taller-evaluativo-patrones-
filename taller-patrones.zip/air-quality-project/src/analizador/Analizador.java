package analizador;

// Product of the Factory Method. Each analyzer knows how to correct a raw reading.
public abstract class Analizador {

    private final String descripcion;
    private final double rangoMaximo;
    private final double incertidumbre; // in percent

    public Analizador(String descripcion, double rangoMaximo, double incertidumbre) {
        this.descripcion = descripcion;
        this.rangoMaximo = rangoMaximo;
        this.incertidumbre = incertidumbre;
    }

    // A reading is valid if it is not negative and not above the equipment range
    public boolean enRango(double cruda) {
        return cruda >= 0 && cruda <= rangoMaximo;
    }

    // The correction lives here, not inside the station
    public abstract double corregir(double cruda, double humedad);

    public String getDescripcion() {
        return descripcion;
    }

    public double getRangoMaximo() {
        return rangoMaximo;
    }

    public double getIncertidumbre() {
        return incertidumbre;
    }
}
