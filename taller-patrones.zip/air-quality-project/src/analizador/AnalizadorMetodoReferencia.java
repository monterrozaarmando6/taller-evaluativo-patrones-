package analizador;

public class AnalizadorMetodoReferencia extends Analizador {

    private final double factorCalibracion;

    public AnalizadorMetodoReferencia(double factorCalibracion) {
        super("reference method analyzer", 1000.0, 2.0);
        this.factorCalibracion = factorCalibracion;
    }

    @Override
    public double corregir(double cruda, double humedad) {
        return cruda * factorCalibracion;
    }
}
