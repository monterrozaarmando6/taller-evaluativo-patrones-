package analizador;

public class SensorBajoCosto extends Analizador {

    public SensorBajoCosto() {
        super("low-cost sensor with humidity correction", 500.0, 20.0);
    }

    @Override
    public double corregir(double cruda, double humedad) {
        if (humedad > 75) {
            return cruda / (1 + 0.012 * (humedad - 75));
        }
        return cruda;
    }
}
