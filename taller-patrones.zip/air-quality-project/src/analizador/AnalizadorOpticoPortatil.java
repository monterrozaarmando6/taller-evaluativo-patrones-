package analizador;

public class AnalizadorOpticoPortatil extends Analizador {

    public AnalizadorOpticoPortatil() {
        super("portable optical analyzer", 800.0, 8.0);
    }

    @Override
    public double corregir(double cruda, double humedad) {
        return cruda * 1.05 + 0.8;
    }
}
