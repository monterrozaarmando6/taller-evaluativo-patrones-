package ica;

// One breakpoint segment: concentration range (cLo-cHi) and ICA range (iLo-iHi)
public class PuntoDeCorte {

    private final double cLo;
    private final double cHi;
    private final int iLo;
    private final int iHi;

    public PuntoDeCorte(double cLo, double cHi, int iLo, int iHi) {
        this.cLo = cLo;
        this.cHi = cHi;
        this.iLo = iLo;
        this.iHi = iHi;
    }

    public double getCLo() {
        return cLo;
    }

    public double getCHi() {
        return cHi;
    }

    public int getILo() {
        return iLo;
    }

    public int getIHi() {
        return iHi;
    }
}
