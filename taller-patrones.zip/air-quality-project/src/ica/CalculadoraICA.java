package ica;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Computes the ICA using a table of breakpoints (no hand-written if chain per pollutant)
public class CalculadoraICA {

    private static final int[] ICA_LO = {0, 51, 101, 151, 201};
    private static final int[] ICA_HI = {50, 100, 150, 200, 300};

    private static final Map<String, List<PuntoDeCorte>> TABLA = new HashMap<>();

    static {
        TABLA.put("PM2.5", crearTramos(
                new double[]{0.0, 12.1, 37.5, 55.5, 150.5},
                new double[]{12.0, 37.4, 55.4, 150.4, 250.4}));
        TABLA.put("O3", crearTramos(
                new double[]{0, 55, 71, 86, 106},
                new double[]{54, 70, 85, 105, 200}));
        TABLA.put("NO2", crearTramos(
                new double[]{0, 54, 101, 361, 650},
                new double[]{53, 100, 360, 649, 1249}));
    }

    private static List<PuntoDeCorte> crearTramos(double[] cLo, double[] cHi) {
        List<PuntoDeCorte> tramos = new ArrayList<>();
        for (int i = 0; i < cLo.length; i++) {
            tramos.add(new PuntoDeCorte(cLo[i], cHi[i], ICA_LO[i], ICA_HI[i]));
        }
        return tramos;
    }

    // Linear interpolation inside the segment that contains the concentration
    public static double calcular(String contaminante, double c) {
        List<PuntoDeCorte> tramos = TABLA.get(contaminante);
        for (PuntoDeCorte t : tramos) {
            if (c <= t.getCHi()) {
                double ica = ((double) (t.getIHi() - t.getILo()) / (t.getCHi() - t.getCLo()))
                        * (c - t.getCLo()) + t.getILo();
                // if c falls in the small gap between two segments, do not go below the segment start
                return Math.max(ica, t.getILo());
            }
        }
        // above the last segment: use the maximum of the table
        return ICA_HI[ICA_HI.length - 1];
    }

    public static String categoria(int ica) {
        if (ica <= 50) {
            return "Good";
        } else if (ica <= 100) {
            return "Acceptable";
        } else if (ica <= 150) {
            return "Unhealthy for sensitive groups";
        } else if (ica <= 200) {
            return "Unhealthy";
        } else {
            return "Very unhealthy";
        }
    }
}
