package boletin;

import puesto.ResultadoEstacion;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Immutable product built with a fluent Builder
public class BoletinDiario {

    // mandatory
    private final LocalDate fecha;
    private final String entidadEmisora;
    private final List<ResultadoEstacion> resultados;
    private final int icaMaximoCiudad;
    private final String categoriaCiudad;

    // optional
    private final String recomendaciones;
    private final String pronostico;
    private final String anexoDatosFaltantes;
    private final String responsable;
    private final String notaMetodologica;

    private BoletinDiario(Builder b) {
        this.fecha = b.fecha;
        this.entidadEmisora = b.entidadEmisora;
        this.resultados = Collections.unmodifiableList(new ArrayList<>(b.resultados));
        this.icaMaximoCiudad = b.icaMaximoCiudad;
        this.categoriaCiudad = b.categoriaCiudad;
        this.recomendaciones = b.recomendaciones;
        this.pronostico = b.pronostico;
        this.anexoDatosFaltantes = b.anexoDatosFaltantes;
        this.responsable = b.responsable;
        this.notaMetodologica = b.notaMetodologica;
    }

    public void publicar() {
        System.out.println("--- DAILY BULLETIN " + fecha + " ---");
        System.out.println("Issued by: " + entidadEmisora);
        System.out.printf("%-3s %-26s %-5s %-32s %s%n", "#", "STATION", "ICA", "CATEGORY", "CRITICAL");
        int puesto = 1;
        for (ResultadoEstacion r : resultados) {
            System.out.printf("%-3d %-26s %-5d %-32s %s%n", puesto, r.getNombre(), r.getIca(),
                    r.getCategoria(), r.getContaminanteCritico());
            puesto++;
        }
        System.out.println("City ICA: " + icaMaximoCiudad + " (" + categoriaCiudad + ")");
        if (recomendaciones != null) {
            System.out.println("Recommendations: " + recomendaciones);
        }
        if (pronostico != null) {
            System.out.println("Forecast for tomorrow: " + pronostico);
        }
        if (anexoDatosFaltantes != null) {
            System.out.println("Missing data annex: " + anexoDatosFaltantes);
        }
        if (responsable != null) {
            System.out.println("Responsible: " + responsable);
        }
        if (notaMetodologica != null) {
            System.out.println("Methodological note: " + notaMetodologica);
        }
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getEntidadEmisora() {
        return entidadEmisora;
    }

    public List<ResultadoEstacion> getResultados() {
        return resultados;
    }

    public int getIcaMaximoCiudad() {
        return icaMaximoCiudad;
    }

    public String getCategoriaCiudad() {
        return categoriaCiudad;
    }

    public String getRecomendaciones() {
        return recomendaciones;
    }

    public String getPronostico() {
        return pronostico;
    }

    public String getAnexoDatosFaltantes() {
        return anexoDatosFaltantes;
    }

    public String getResponsable() {
        return responsable;
    }

    public String getNotaMetodologica() {
        return notaMetodologica;
    }

    public static class Builder {

        private LocalDate fecha;
        private String entidadEmisora;
        private List<ResultadoEstacion> resultados;
        private Integer icaMaximoCiudad;
        private String categoriaCiudad;

        private String recomendaciones;
        private String pronostico;
        private String anexoDatosFaltantes;
        private String responsable;
        private String notaMetodologica;

        public Builder fecha(LocalDate fecha) {
            this.fecha = fecha;
            return this;
        }

        public Builder entidadEmisora(String entidadEmisora) {
            this.entidadEmisora = entidadEmisora;
            return this;
        }

        public Builder resultados(List<ResultadoEstacion> resultados) {
            this.resultados = resultados;
            return this;
        }

        public Builder icaMaximoCiudad(int icaMaximoCiudad) {
            this.icaMaximoCiudad = icaMaximoCiudad;
            return this;
        }

        public Builder categoriaCiudad(String categoriaCiudad) {
            this.categoriaCiudad = categoriaCiudad;
            return this;
        }

        public Builder recomendaciones(String recomendaciones) {
            this.recomendaciones = recomendaciones;
            return this;
        }

        public Builder pronostico(String pronostico) {
            this.pronostico = pronostico;
            return this;
        }

        public Builder anexoDatosFaltantes(String anexoDatosFaltantes) {
            this.anexoDatosFaltantes = anexoDatosFaltantes;
            return this;
        }

        public Builder responsable(String responsable) {
            this.responsable = responsable;
            return this;
        }

        public Builder notaMetodologica(String notaMetodologica) {
            this.notaMetodologica = notaMetodologica;
            return this;
        }

        public BoletinDiario build() {
            if (fecha == null) {
                throw new IllegalStateException("The date is mandatory");
            }
            if (entidadEmisora == null || entidadEmisora.trim().isEmpty()) {
                throw new IllegalStateException("The issuing entity is mandatory");
            }
            if (resultados == null) {
                throw new IllegalStateException("The list of station results is mandatory");
            }
            if (resultados.isEmpty()) {
                throw new IllegalStateException("The list of stations cannot be empty");
            }
            if (icaMaximoCiudad == null) {
                throw new IllegalStateException("The maximum ICA of the city is mandatory");
            }
            if (categoriaCiudad == null || categoriaCiudad.trim().isEmpty()) {
                throw new IllegalStateException("The city category is mandatory");
            }
            boolean categoriaGrave = categoriaCiudad.equals("Unhealthy") || categoriaCiudad.equals("Very unhealthy");
            if (categoriaGrave && (recomendaciones == null || recomendaciones.trim().isEmpty())) {
                throw new IllegalStateException(
                        "Category '" + categoriaCiudad + "' requires recommendations for sensitive population");
            }
            return new BoletinDiario(this);
        }
    }
}
