package app;

import boletin.BoletinDiario;
import configuracion.ConfiguracionEstacion;
import configuracion.TareaMantenimiento;
import puesto.LecturaCorregida;
import puesto.LecturaCruda;
import puesto.PuestoBajoCosto;
import puesto.PuestoDeMonitoreo;
import puesto.PuestoFijoReferencia;
import puesto.PuestoMovil;
import puesto.ResultadoContaminante;
import puesto.ResultadoEstacion;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        System.out.println("=== ENVIRONMENT SECRETARIAT - AIR QUALITY NETWORK ===");

        demoPrototype();
        List<ResultadoEstacion> resultados = procesarEstaciones();
        rankear(resultados);
        publicarBoletin(resultados);
    }

    // ---------- Prototype demo ----------
    private static void demoPrototype() {
        ConfiguracionEstacion modelo = new ConfiguracionEstacion("Residential zone", "residential", 60);
        modelo.agregarContaminante("PM2.5");
        modelo.agregarContaminante("O3");
        modelo.agregarContaminante("NO2");
        modelo.setUmbral("PM2.5", 37.5);
        modelo.setUmbral("O3", 70.0);
        modelo.setUmbral("NO2", 100.0);
        modelo.agregarTarea(new TareaMantenimiento("Clean inlet filter", 7));
        modelo.agregarTarea(new TareaMantenimiento("Calibrate analyzer", 30));
        modelo.agregarTarea(new TareaMantenimiento("Replace pump", 180));

        ConfiguracionEstacion parque = modelo.clone();
        parque.setNombre("Parque Centenario");
        ConfiguracionEstacion colegio = modelo.clone();
        colegio.setNombre("Colegio San Jose");

        // change only the second clone
        colegio.setUmbral("PM2.5", 25.0);
        colegio.agregarTarea(new TareaMantenimiento("Check rain shield", 15));

        System.out.println("Model config '" + modelo.getNombre() + "' " + resumen(modelo));
        System.out.println("Station " + parque.getNombre() + " " + resumen(parque));
        System.out.println("Station " + colegio.getNombre() + " " + resumen(colegio) + " <- modified");
        System.out.println("Model check -> " + resumen(modelo) + " (intact)");
        System.out.println("Other clone check -> " + resumen(parque) + " (intact)");
        System.out.println();
    }

    private static String resumen(ConfiguracionEstacion c) {
        return "PM2.5 threshold=" + c.getUmbral("PM2.5") + " tasks: " + c.getCantidadTareas();
    }

    // ---------- Factory Method demo ----------
    private static List<ResultadoEstacion> procesarEstaciones() {
        Random random = new Random(42); // fixed seed, reproducible output

        PuestoDeMonitoreo quebradaseca = new PuestoFijoReferencia("Av. Quebradaseca", 1.02);
        PuestoDeMonitoreo centenario = new PuestoFijoReferencia("Parque Centenario", 1.01);
        PuestoDeMonitoreo movil = new PuestoMovil("Unidad movil - Zona Ind.");
        PuestoDeMonitoreo colegio = new PuestoBajoCosto("Colegio San Jose");

        // readings of each station
        List<LecturaCruda> lecQuebradaseca = new ArrayList<>();
        lecQuebradaseca.addAll(generar(random, "PM2.5", 20, 8, 24, 55));
        lecQuebradaseca.addAll(generar(random, "O3", 30, 15, 24, 55));
        lecQuebradaseca.addAll(generar(random, "NO2", 60, 30, 24, 55));

        List<LecturaCruda> lecCentenario = new ArrayList<>();
        lecCentenario.addAll(generar(random, "PM2.5", 8, 4, 24, 55));
        lecCentenario.addAll(generar(random, "O3", 20, 10, 24, 55));
        lecCentenario.addAll(generar(random, "NO2", 30, 15, 24, 55));

        List<LecturaCruda> lecMovil = new ArrayList<>();
        lecMovil.addAll(generar(random, "PM2.5", 15, 10, 24, 60));
        lecMovil.addAll(generar(random, "O3", 40, 10, 24, 60));
        lecMovil.addAll(generar(random, "NO2", 40, 20, 24, 60));

        // low-cost station: humidity above 75 % and some problems
        List<LecturaCruda> pm25Colegio = generar(random, "PM2.5", 45, 15, 24, 82);
        pm25Colegio.set(3, new LecturaCruda(3, "PM2.5", -1.0, 85));    // negative reading
        pm25Colegio.set(15, new LecturaCruda(15, "PM2.5", 900.0, 85)); // above the range
        List<LecturaCruda> lecColegio = new ArrayList<>();
        lecColegio.addAll(pm25Colegio);
        lecColegio.addAll(generar(random, "O3", 30, 10, 15, 82));      // only 15 readings
        lecColegio.addAll(generar(random, "NO2", 30, 20, 24, 82));

        System.out.println("--- STATION PROCESSING ---");
        List<ResultadoEstacion> resultados = new ArrayList<>();
        PuestoDeMonitoreo[] puestos = {quebradaseca, centenario, movil, colegio};
        List<List<LecturaCruda>> todasLecturas = new ArrayList<>();
        todasLecturas.add(lecQuebradaseca);
        todasLecturas.add(lecCentenario);
        todasLecturas.add(lecMovil);
        todasLecturas.add(lecColegio);

        for (int i = 0; i < puestos.length; i++) {
            ResultadoEstacion r = puestos[i].procesarJornada(todasLecturas.get(i));
            imprimirEstacion(r);
            resultados.add(r);
        }
        System.out.println();
        return resultados;
    }

    // generates 'horas' readings: base + random * spread, humidity = hrBase + random * 8
    private static List<LecturaCruda> generar(Random random, String contaminante, double base,
                                              double spread, int horas, double hrBase) {
        List<LecturaCruda> lista = new ArrayList<>();
        for (int h = 0; h < horas; h++) {
            double valor = Math.round((base + random.nextDouble() * spread) * 100.0) / 100.0;
            double humedad = Math.round(hrBase + random.nextDouble() * 8);
            lista.add(new LecturaCruda(h, contaminante, valor, humedad));
        }
        return lista;
    }

    private static void imprimirEstacion(ResultadoEstacion r) {
        System.out.println("[" + r.getNombre() + "] type " + r.getTipo() + " - " + r.getDescripcionAnalizador());
        for (ResultadoContaminante c : r.getResultados()) {
            // for the low-cost station show raw vs corrected for 3 hours with HR > 75 %
            if (r.getTipo().equals("BAJO_COSTO")) {
                int mostradas = 0;
                for (LecturaCorregida l : c.getLecturas()) {
                    if (l.getHumedad() > 75 && mostradas < 3) {
                        System.out.printf("  %s h%02d raw %.2f HR %.0f %% -> corrected %.2f%n",
                                c.getContaminante(), l.getHora(), l.getCruda(), l.getHumedad(), l.getCorregida());
                        mostradas++;
                    }
                }
            }
            System.out.print("  discarded: " + c.getDescartadas() + " | valid: " + c.getValidas() + " of 24 -> ");
            if (c.isValido()) {
                String unidad = c.getContaminante().equals("PM2.5") ? "ug/m3" : "ppb";
                System.out.printf("%s 24h average: %.2f %s -> ICA %d (%s)%n", c.getContaminante(),
                        c.getPromedio(), unidad, Math.round(c.getIca()),
                        ica.CalculadoraICA.categoria((int) Math.round(c.getIca())));
            } else {
                System.out.println(c.getContaminante() + " INSUFFICIENT DATA");
            }
        }
        System.out.println("  Station ICA: " + r.getIca() + " (" + r.getCategoria()
                + "), critical pollutant: " + r.getContaminanteCritico());
    }

    // ---------- ranking: ICA descending, then name ----------
    private static void rankear(List<ResultadoEstacion> resultados) {
        resultados.sort((a, b) -> {
            if (a.getIca() != b.getIca()) {
                return Integer.compare(b.getIca(), a.getIca());
            }
            return a.getNombre().compareTo(b.getNombre());
        });
    }

    // ---------- network coverage ----------
    private static double coberturaRed(List<ResultadoEstacion> resultados) {
        int validas = 0;
        int esperadas = 0;
        for (ResultadoEstacion r : resultados) {
            validas += r.getLecturasValidas();
            esperadas += r.getLecturasEsperadas();
        }
        return validas * 100.0 / esperadas;
    }

    // ---------- Builder demo ----------
    private static void publicarBoletin(List<ResultadoEstacion> resultados) {
        ResultadoEstacion peor = resultados.get(0); // first after ranking = highest ICA

        StringBuilder faltantes = new StringBuilder();
        for (ResultadoEstacion r : resultados) {
            for (ResultadoContaminante c : r.getResultados()) {
                if (!c.isValido()) {
                    faltantes.append(c.getContaminante()).append(" at ").append(r.getNombre())
                            .append(": only ").append(c.getValidas()).append(" valid readings. ");
                }
            }
        }

        BoletinDiario boletin = new BoletinDiario.Builder()
                .fecha(LocalDate.of(2026, 8, 14))
                .entidadEmisora("Environment Secretariat")
                .resultados(resultados)
                .icaMaximoCiudad(peor.getIca())
                .categoriaCiudad(peor.getCategoria())
                .recomendaciones("People with asthma and children should avoid outdoor physical activity.")
                .pronostico("Similar air quality expected tomorrow.")
                .anexoDatosFaltantes(faltantes.toString().trim())
                .responsable("Air Quality Office")
                .notaMetodologica("Low-cost sensors are corrected for humidity before computing the ICA.")
                .build();

        boletin.publicar();
        System.out.printf("Valid data coverage of the network: %.1f %%%n", coberturaRed(resultados));

        // invalid bulletin: "Unhealthy" category without recommendations
        System.out.println();
        System.out.println("--- TRYING TO BUILD AN INVALID BULLETIN ---");
        try {
            new BoletinDiario.Builder()
                    .fecha(LocalDate.of(2026, 8, 14))
                    .entidadEmisora("Environment Secretariat")
                    .resultados(resultados)
                    .icaMaximoCiudad(160)
                    .categoriaCiudad("Unhealthy")
                    .build();
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
