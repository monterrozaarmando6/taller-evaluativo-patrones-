package configuracion;

public class TareaMantenimiento {

    private final String descripcion;
    private final int periodicidadDias;

    public TareaMantenimiento(String descripcion, int periodicidadDias) {
        this.descripcion = descripcion;
        this.periodicidadDias = periodicidadDias;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getPeriodicidadDias() {
        return periodicidadDias;
    }
}
