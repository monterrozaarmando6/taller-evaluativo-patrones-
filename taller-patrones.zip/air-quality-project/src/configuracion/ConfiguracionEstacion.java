package configuracion;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Prototype: a model configuration that is deep-cloned for each new station
public class ConfiguracionEstacion implements Cloneable {

    private String nombre;
    private String tipoZona;
    private int intervaloMuestreoMinutos;
    private List<String> contaminantes = new ArrayList<>();
    private Map<String, Double> umbrales = new LinkedHashMap<>();
    private List<TareaMantenimiento> planMantenimiento = new ArrayList<>();

    public ConfiguracionEstacion(String nombre, String tipoZona, int intervaloMuestreoMinutos) {
        this.nombre = nombre;
        this.tipoZona = tipoZona;
        this.intervaloMuestreoMinutos = intervaloMuestreoMinutos;
    }

    // Deep clone: the map and both lists are copied, and each task is a new object
    @Override
    public ConfiguracionEstacion clone() {
        try {
            ConfiguracionEstacion copia = (ConfiguracionEstacion) super.clone();
            copia.contaminantes = new ArrayList<>(this.contaminantes);
            copia.umbrales = new LinkedHashMap<>(this.umbrales);
            copia.planMantenimiento = new ArrayList<>();
            for (TareaMantenimiento t : this.planMantenimiento) {
                copia.planMantenimiento.add(new TareaMantenimiento(t.getDescripcion(), t.getPeriodicidadDias()));
            }
            return copia;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public void agregarContaminante(String contaminante) {
        contaminantes.add(contaminante);
    }

    public void setUmbral(String contaminante, double umbral) {
        umbrales.put(contaminante, umbral);
    }

    public void agregarTarea(TareaMantenimiento tarea) {
        planMantenimiento.add(tarea);
    }

    public double getUmbral(String contaminante) {
        return umbrales.get(contaminante);
    }

    public int getCantidadTareas() {
        return planMantenimiento.size();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoZona() {
        return tipoZona;
    }

    public int getIntervaloMuestreoMinutos() {
        return intervaloMuestreoMinutos;
    }

    public List<String> getContaminantes() {
        return contaminantes;
    }
}
