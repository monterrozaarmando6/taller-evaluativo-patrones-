package puesto;

import analizador.Analizador;
import ica.CalculadoraICA;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Creator of the Factory Method pattern
public abstract class PuestoDeMonitoreo {

    public static final int LECTURAS_ESPERADAS = 24;
    public static final int MINIMO_VALIDAS = 18;

    private final String nombre;
    private final String tipo;

    public PuestoDeMonitoreo(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    // Factory method: each subclass decides which analyzer to create
    protected abstract Analizador crearAnalizador(String contaminante);

    // Template of the process: discard, correct, check validity, average, ICA
    public ResultadoEstacion procesarJornada(List<LecturaCruda> lecturas) {
        // group the readings by pollutant
        Map<String, List<LecturaCruda>> porContaminante = new LinkedHashMap<>();
        for (LecturaCruda l : lecturas) {
            if (!porContaminante.containsKey(l.getContaminante())) {
                porContaminante.put(l.getContaminante(), new ArrayList<>());
            }
            porContaminante.get(l.getContaminante()).add(l);
        }

        List<ResultadoContaminante> resultados = new ArrayList<>();
        String descripcionAnalizador = "";

        for (Map.Entry<String, List<LecturaCruda>> entrada : porContaminante.entrySet()) {
            String contaminante = entrada.getKey();
            Analizador analizador = crearAnalizador(contaminante);
            descripcionAnalizador = analizador.getDescripcion()
                    + " (+/- " + analizador.getIncertidumbre() + " %)";

            int descartadas = 0;
            List<LecturaCorregida> validas = new ArrayList<>();

            for (LecturaCruda l : entrada.getValue()) {
                // 1. discard negative or out of range readings
                if (!analizador.enRango(l.getValor())) {
                    descartadas++;
                } else {
                    // 2. correct the reading with the analyzer
                    double corregida = analizador.corregir(l.getValor(), l.getHumedad());
                    validas.add(new LecturaCorregida(l.getHora(), l.getValor(), l.getHumedad(), corregida));
                }
            }

            // 3. validity and 24h average
            boolean valido = validas.size() >= MINIMO_VALIDAS;
            double promedio = 0;
            double ica = 0;
            if (valido) {
                double suma = 0;
                for (LecturaCorregida c : validas) {
                    suma += c.getCorregida();
                }
                promedio = Math.round(suma / validas.size() * 100.0) / 100.0;
                // 4. ICA of the pollutant
                ica = CalculadoraICA.calcular(contaminante, promedio);
            }

            resultados.add(new ResultadoContaminante(contaminante, descartadas, validas.size(),
                    valido, promedio, ica, validas));
        }

        // 5. ICA of the station: maximum of the valid pollutants
        double icaMaximo = -1;
        String critico = "NONE";
        for (ResultadoContaminante r : resultados) {
            if (r.isValido() && r.getIca() > icaMaximo) {
                icaMaximo = r.getIca();
                critico = r.getContaminante();
            }
        }
        int icaEstacion = 0;
        String categoria = "No data";
        if (icaMaximo >= 0) {
            icaEstacion = (int) Math.round(icaMaximo);
            categoria = CalculadoraICA.categoria(icaEstacion);
        }

        return new ResultadoEstacion(nombre, tipo, descripcionAnalizador, resultados,
                icaEstacion, critico, categoria);
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }
}
