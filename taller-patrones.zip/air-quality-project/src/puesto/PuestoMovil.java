package puesto;

import analizador.Analizador;
import analizador.AnalizadorOpticoPortatil;

public class PuestoMovil extends PuestoDeMonitoreo {

    public PuestoMovil(String nombre) {
        super(nombre, "MOVIL");
    }

    @Override
    protected Analizador crearAnalizador(String contaminante) {
        return new AnalizadorOpticoPortatil();
    }
}
