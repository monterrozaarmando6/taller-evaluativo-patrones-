package puesto;

import analizador.Analizador;
import analizador.SensorBajoCosto;

public class PuestoBajoCosto extends PuestoDeMonitoreo {

    public PuestoBajoCosto(String nombre) {
        super(nombre, "BAJO_COSTO");
    }

    @Override
    protected Analizador crearAnalizador(String contaminante) {
        return new SensorBajoCosto();
    }
}
