package puesto;

import analizador.Analizador;
import analizador.AnalizadorMetodoReferencia;

public class PuestoFijoReferencia extends PuestoDeMonitoreo {

    private final double factorCalibracion;

    public PuestoFijoReferencia(String nombre, double factorCalibracion) {
        super(nombre, "FIJO_REFERENCIA");
        this.factorCalibracion = factorCalibracion;
    }

    @Override
    protected Analizador crearAnalizador(String contaminante) {
        return new AnalizadorMetodoReferencia(factorCalibracion);
    }
}
