package puesto;

public class LecturaCorregida {

    private final int hora;
    private final double cruda;
    private final double humedad;
    private final double corregida;

    public LecturaCorregida(int hora, double cruda, double humedad, double corregida) {
        this.hora = hora;
        this.cruda = cruda;
        this.humedad = humedad;
        this.corregida = corregida;
    }

    public int getHora() {
        return hora;
    }

    public double getCruda() {
        return cruda;
    }

    public double getHumedad() {
        return humedad;
    }

    public double getCorregida() {
        return corregida;
    }
}
