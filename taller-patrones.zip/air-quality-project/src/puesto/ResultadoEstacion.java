package puesto;

import java.util.List;

public class ResultadoEstacion {

    private final String nombre;
    private final String tipo;
    private final String descripcionAnalizador;
    private final List<ResultadoContaminante> resultados;
    private final int ica;
    private final String contaminanteCritico;
    private final String categoria;

    public ResultadoEstacion(String nombre, String tipo, String descripcionAnalizador,
                             List<ResultadoContaminante> resultados, int ica,
                             String contaminanteCritico, String categoria) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.descripcionAnalizador = descripcionAnalizador;
        this.resultados = resultados;
        this.ica = ica;
        this.contaminanteCritico = contaminanteCritico;
        this.categoria = categoria;
    }

    // valid readings (after discarding) of all pollutants of this station
    public int getLecturasValidas() {
        int total = 0;
        for (ResultadoContaminante r : resultados) {
            total += r.getValidas();
        }
        return total;
    }

    // expected readings: pollutants x 24
    public int getLecturasEsperadas() {
        return resultados.size() * PuestoDeMonitoreo.LECTURAS_ESPERADAS;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public String getDescripcionAnalizador() {
        return descripcionAnalizador;
    }

    public List<ResultadoContaminante> getResultados() {
        return resultados;
    }

    public int getIca() {
        return ica;
    }

    public String getContaminanteCritico() {
        return contaminanteCritico;
    }

    public String getCategoria() {
        return categoria;
    }
}
