package puesto;

import java.util.List;

public class ResultadoContaminante {

    private final String contaminante;
    private final int descartadas;
    private final int validas;
    private final boolean valido;
    private final double promedio;
    private final double ica;
    private final List<LecturaCorregida> lecturas;

    public ResultadoContaminante(String contaminante, int descartadas, int validas, boolean valido,
                                 double promedio, double ica, List<LecturaCorregida> lecturas) {
        this.contaminante = contaminante;
        this.descartadas = descartadas;
        this.validas = validas;
        this.valido = valido;
        this.promedio = promedio;
        this.ica = ica;
        this.lecturas = lecturas;
    }

    public String getContaminante() {
        return contaminante;
    }

    public int getDescartadas() {
        return descartadas;
    }

    public int getValidas() {
        return validas;
    }

    public boolean isValido() {
        return valido;
    }

    public double getPromedio() {
        return promedio;
    }

    public double getIca() {
        return ica;
    }

    public List<LecturaCorregida> getLecturas() {
        return lecturas;
    }
}
