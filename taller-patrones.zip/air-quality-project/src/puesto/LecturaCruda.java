package puesto;

public class LecturaCruda {

    private final int hora;
    private final String contaminante;
    private final double valor;
    private final double humedad; // relative humidity in %

    public LecturaCruda(int hora, String contaminante, double valor, double humedad) {
        this.hora = hora;
        this.contaminante = contaminante;
        this.valor = valor;
        this.humedad = humedad;
    }

    public int getHora() {
        return hora;
    }

    public String getContaminante() {
        return contaminante;
    }

    public double getValor() {
        return valor;
    }

    public double getHumedad() {
        return humedad;
    }
}
